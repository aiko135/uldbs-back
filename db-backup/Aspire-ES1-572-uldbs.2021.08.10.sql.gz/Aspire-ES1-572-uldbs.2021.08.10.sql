--
-- PostgreSQL database dump
--

-- Dumped from database version 13.1 (Ubuntu 13.1-1.pgdg20.04+1)
-- Dumped by pg_dump version 13.1 (Ubuntu 13.1-1.pgdg20.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: add_chat_if_notexists(uuid, uuid); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.add_chat_if_notexists(client_id uuid, manager_id uuid)
    LANGUAGE plpgsql
    AS $$
begin
	if not exists(
		select 1 from chat ch 
		where ch.client_uuid  = client_id 
		and ch.manager_uuid = manager_id)
	then 
		INSERT INTO public.chat
		(uuid, client_uuid, manager_uuid)
		VALUES(uuid_generate_v4(), client_id, manager_id);
	end if;	
end
$$;


ALTER PROCEDURE public.add_chat_if_notexists(client_id uuid, manager_id uuid) OWNER TO postgres;

--
-- Name: after_stat_histor_add_proc(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.after_stat_histor_add_proc() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare 
	status_f status%ROWTYPE; 
begin 
	SELECT * into status_f FROM status s WHERE s.uuid = NEW.status_uuid;
	if status_f is not null 
	and status_f.prev_status IS NOT NULL
	AND NOT EXISTS (SELECT sh.uuid FROM status_history sh 
					WHERE sh.request_uuid = NEW.request_uuid AND sh.status_uuid = status_f.prev_status)
	THEN
		INSERT INTO public.status_history
		(uuid, request_uuid, status_uuid, setup_timestamp, "comment")
		VALUES(uuid_generate_v4(), NEW.request_uuid, status_f.prev_status, NEW.setup_timestamp, NEW."comment");
	END IF;
	return NULL;
end
$$;


ALTER FUNCTION public.after_stat_histor_add_proc() OWNER TO postgres;

--
-- Name: getfreemanager(integer, uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getfreemanager(mng_role_code integer, rqst_finish_stat uuid) RETURNS uuid
    LANGUAGE sql
    AS $$

select mangr_uuid from(

select u.uuid as mangr_uuid,
(select count(*) from request r where not exists (
		select 1 from status_history sh where 
			sh.request_uuid = r.uuid 
			and sh.status_uuid = rqst_finish_stat
		)
		and r.manager_uuid = u.uuid
) as not_finished_requests 
from "user" u where u."role" = mng_role_code

) as analyzing order by not_finished_requests limit 1; 

$$;


ALTER FUNCTION public.getfreemanager(mng_role_code integer, rqst_finish_stat uuid) OWNER TO postgres;

--
-- Name: getworthfromuser(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.getworthfromuser(user_id uuid) RETURNS integer
    LANGUAGE sql
    AS $$

select sum(g.price) as worth
from "user" u left join good g  on g.uuid in 
	(select gr.good_uuid from good_request gr where
	gr.request_uuid in (
		select rq.uuid from request rq where rq.client_uuid = u.uuid))
where u.uuid = user_id
group by u.uuid 
order by worth desc
LIMIT 1;

$$;


ALTER FUNCTION public.getworthfromuser(user_id uuid) OWNER TO postgres;

--
-- Name: init_request(uuid); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.init_request(user_id uuid)
    LANGUAGE plpgsql
    AS $$
begin
    select * from "user" u2;
end;
$$;


ALTER PROCEDURE public.init_request(user_id uuid) OWNER TO postgres;

--
-- Name: init_request(uuid, text, uuid[]); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.init_request(user_id uuid, paymentdata text, VARIADIC goods uuid[]) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
declare 
	m_role_code integer;
	finish_status uuid;
	start_status uuid;
	manager_id uuid;
	new_req_id  uuid; 
	good uuid;
begin
	m_role_code  := 2;
	start_status := '1167829b-ecfe-484c-a4fe-3e086d8c4d97';
	finish_status := 'ad631ed1-a650-4f9c-bfa1-70b84c6f0d10';
	
	manager_id := getfreemanager(m_role_code,finish_status);
	new_req_id  := uuid_generate_v4();

	INSERT INTO public.request
	(uuid, client_uuid, manager_uuid, payment_data)
	VALUES(new_req_id, user_id, manager_id ,paymentdata);
	
	INSERT INTO public.status_history
	(uuid, request_uuid, status_uuid, setup_timestamp, "comment")
	VALUES(uuid_generate_v4(), new_req_id, start_status, CURRENT_TIMESTAMP, '');
	
	foreach good in array goods
	loop
		INSERT INTO public.good_request
		(uuid, request_uuid, good_uuid)
		VALUES(uuid_generate_v4(), new_req_id, good);
	end loop;

	return new_req_id;
end;
$$;


ALTER FUNCTION public.init_request(user_id uuid, paymentdata text, VARIADIC goods uuid[]) OWNER TO postgres;

--
-- Name: instead_of_user_data(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.instead_of_user_data() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
declare 
	user_id uuid; 
begin 
	if tg_op = 'INSERT' then 
		user_id := uuid_generate_v4(); 
	
		INSERT INTO public."user"
		(uuid, email, pass, "role", "name", birth_date, phone)
		VALUES(user_id, new.email, new.pass,new."role", new."name",  new.birth_date, new.phone);
	
		call update_chats(user_id);
		return new;
	elseif tg_op = 'UPDATE'then
		update public."user" set
			email = new.email,
			pass = new.pass,
			"name" = new."name",
			"role" = new."role" ,
			birth_date  = new.birth_date,
			phone = new.phone
		where uuid = new.uuid;
		return new;
	elseif tg_op = 'DELETE' then
		delete from public."user" u where u.uuid = old.uuid;
		return new;
	end if;
end
$$;


ALTER FUNCTION public.instead_of_user_data() OWNER TO postgres;

--
-- Name: on_feedback_add_func(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.on_feedback_add_func() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin 
	IF NOT EXISTS(
		SELECT 1 FROM request r2 
		WHERE r2.client_uuid = NEW.user_uuid
		AND EXISTS(
			SELECT 1 FROM good_request gr
			WHERE gr.good_uuid = NEW.good_uuid))
	THEN 
		RAISE EXCEPTION 'A person should buy a good before giving a feedback';
	ELSE
		return new;
	END IF;
	
end
$$;


ALTER FUNCTION public.on_feedback_add_func() OWNER TO postgres;

--
-- Name: update_chats(uuid); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.update_chats(user_id uuid)
    LANGUAGE plpgsql
    AS $$
declare 
	finish_status uuid; 
	manager_id uuid;
	m_role_code integer;
	found_request request%ROWTYPE;
begin
	finish_status := 'ad631ed1-a650-4f9c-bfa1-70b84c6f0d10';

	
	select * into found_request from request r2 
	where r2.client_uuid = user_id
	and not exists (select * from status_history sh 
					 where sh.request_uuid = r2.uuid 
					and sh.status_uuid = finish_status); 
	if found then 
		manager_id := found_request.manager_uuid;
		call add_chat_if_notexists(user_id, manager_id );
	else 
		m_role_code  := 2;
		manager_id := getfreemanager(m_role_code, finish_status);
		call add_chat_if_notexists(user_id, manager_id);
	end if;
end;
$$;


ALTER PROCEDURE public.update_chats(user_id uuid) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: good; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.good (
    uuid uuid NOT NULL,
    name character varying(256) NOT NULL,
    price numeric(16,2) NOT NULL,
    descr text NOT NULL,
    img_path character varying(512),
    catalog_uuid uuid
);


ALTER TABLE public.good OWNER TO postgres;

--
-- Name: all_by_grades; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.all_by_grades AS
SELECT
    NULL::public.good AS g,
    NULL::character varying(128) AS catal,
    NULL::numeric AS avrg_grade;


ALTER TABLE public.all_by_grades OWNER TO postgres;

--
-- Name: all_by_reqeust_count; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.all_by_reqeust_count AS
SELECT
    NULL::public.good AS g,
    NULL::character varying(128) AS catal,
    NULL::bigint AS request_count;


ALTER TABLE public.all_by_reqeust_count OWNER TO postgres;

--
-- Name: catalog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.catalog (
    uuid uuid NOT NULL,
    name character varying(128) NOT NULL
);


ALTER TABLE public.catalog OWNER TO postgres;

--
-- Name: chat; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.chat (
    uuid uuid NOT NULL,
    client_uuid uuid NOT NULL,
    manager_uuid uuid NOT NULL
);


ALTER TABLE public.chat OWNER TO postgres;

--
-- Name: feedback; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.feedback (
    uuid uuid NOT NULL,
    user_uuid uuid NOT NULL,
    good_uuid uuid NOT NULL,
    grade smallint NOT NULL,
    feedback text,
    "timestamp" timestamp(0) without time zone NOT NULL
);


ALTER TABLE public.feedback OWNER TO postgres;

--
-- Name: good_request; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.good_request (
    uuid uuid NOT NULL,
    request_uuid uuid NOT NULL,
    good_uuid uuid NOT NULL
);


ALTER TABLE public.good_request OWNER TO postgres;

--
-- Name: managers_by_requests; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.managers_by_requests AS
SELECT
    NULL::uuid AS uuid,
    NULL::character varying(128) AS email,
    NULL::character varying(64) AS pass,
    NULL::smallint AS role,
    NULL::character varying(64) AS name,
    NULL::date AS birth_date,
    NULL::character varying(11) AS phone,
    NULL::bigint AS requests;


ALTER TABLE public.managers_by_requests OWNER TO postgres;

--
-- Name: managers_by_worth; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.managers_by_worth AS
SELECT
    NULL::uuid AS uuid,
    NULL::character varying(128) AS email,
    NULL::character varying(64) AS pass,
    NULL::smallint AS role,
    NULL::character varying(64) AS name,
    NULL::date AS birth_date,
    NULL::character varying(11) AS phone,
    NULL::numeric AS worth;


ALTER TABLE public.managers_by_worth OWNER TO postgres;

--
-- Name: message; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.message (
    uuid uuid NOT NULL,
    chat_uuid uuid NOT NULL,
    user_uuid uuid NOT NULL,
    text text NOT NULL,
    "timestamp" timestamp(0) without time zone NOT NULL
);


ALTER TABLE public.message OWNER TO postgres;

--
-- Name: parametr; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parametr (
    uuid uuid NOT NULL,
    good_uuid uuid NOT NULL,
    question character varying(512) NOT NULL,
    name character varying(128) NOT NULL
);


ALTER TABLE public.parametr OWNER TO postgres;

--
-- Name: parametr_value; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.parametr_value (
    uuid uuid NOT NULL,
    parametr_uuid uuid NOT NULL,
    good_request_uuid uuid NOT NULL,
    value character varying(256) NOT NULL
);


ALTER TABLE public.parametr_value OWNER TO postgres;

--
-- Name: request; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.request (
    uuid uuid NOT NULL,
    client_uuid uuid NOT NULL,
    manager_uuid uuid NOT NULL,
    payment_data text NOT NULL
);


ALTER TABLE public.request OWNER TO postgres;

--
-- Name: status; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.status (
    uuid uuid NOT NULL,
    name character varying(64) NOT NULL,
    prev_status uuid,
    is_terminal smallint DEFAULT 0 NOT NULL,
    is_initial smallint DEFAULT 0 NOT NULL
);


ALTER TABLE public.status OWNER TO postgres;

--
-- Name: status_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.status_history (
    uuid uuid NOT NULL,
    request_uuid uuid NOT NULL,
    status_uuid uuid NOT NULL,
    setup_timestamp timestamp(0) without time zone NOT NULL,
    comment text
);


ALTER TABLE public.status_history OWNER TO postgres;

--
-- Name: user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."user" (
    uuid uuid NOT NULL,
    email character varying(128) NOT NULL,
    pass character varying(64) NOT NULL,
    role smallint NOT NULL,
    name character varying(64),
    birth_date date,
    phone character varying(11)
);


ALTER TABLE public."user" OWNER TO postgres;

--
-- Name: user_and_info; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.user_and_info AS
SELECT
    NULL::uuid AS uuid,
    NULL::date AS birth_date,
    NULL::character varying(128) AS email,
    NULL::character varying(64) AS name,
    NULL::character varying(64) AS pass,
    NULL::character varying(11) AS phone,
    NULL::smallint AS role,
    NULL::bigint AS reqests,
    NULL::bigint AS messeges,
    NULL::bigint AS feedbacks;


ALTER TABLE public.user_and_info OWNER TO postgres;

--
-- Data for Name: catalog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.catalog (uuid, name) FROM stdin;
982994c3-c5b1-4564-9416-b526cba23075	Основное
767a4621-304c-47b8-b9df-8bd3460be3a7	Электроника
\.


--
-- Data for Name: chat; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.chat (uuid, client_uuid, manager_uuid) FROM stdin;
811c08dd-3cbe-46a3-a586-220a064c3327	012318fb-a204-4729-8a67-898f45f0a125	9efdf923-76b5-4604-939c-35ac5cf131d3
b756705f-89db-4a2b-90e3-75199c4b7965	0aab3e7f-cde2-4b0d-ac93-141c987be013	9efdf923-76b5-4604-939c-35ac5cf131d3
71fb6b39-6ffc-444c-a57a-21914c4b7017	c2d28373-6c1f-485e-bc49-239874ba0601	012318fb-a204-4729-8a67-898f45f0a125
8ecd09f6-8715-430f-9597-650c4615e17c	c2d28373-6c1f-485e-bc49-239874ba0601	9efdf923-76b5-4604-939c-35ac5cf131d3
183e1421-5252-42a1-9d0b-93be656d9de7	0aab3e7f-cde2-4b0d-ac93-141c987be013	012318fb-a204-4729-8a67-898f45f0a125
e6a2e469-067e-4ffe-8575-a089cb75126a	b3290c0d-8a76-4619-9401-13d0a2459fd1	012318fb-a204-4729-8a67-898f45f0a125
\.


--
-- Data for Name: feedback; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.feedback (uuid, user_uuid, good_uuid, grade, feedback, "timestamp") FROM stdin;
a0a97f90-ca9d-48f4-826a-af1d082830e1	c2d28373-6c1f-485e-bc49-239874ba0601	40ba12c7-82a4-4481-9cd6-4000eb286815	5	Очень понравилось!	2020-12-03 21:11:55
0be73f79-2689-4057-94ec-69c67b22d408	c2d28373-6c1f-485e-bc49-239874ba0601	d82477f0-60ef-4f95-b365-d6bc0f6612fa	4	\N	2020-12-03 21:11:55
fce167b9-673f-44a3-9c0f-0eeb300593c0	c2d28373-6c1f-485e-bc49-239874ba0601	f691ab28-e35b-4b12-9de2-b2cd2287eb7b	1	Плохое качество	2020-12-03 21:11:55
9b71fd08-91b9-4378-bb33-62cba9875478	c2d28373-6c1f-485e-bc49-239874ba0601	40ba12c7-82a4-4481-9cd6-4000eb286815	4	Есть недостатки!	2020-12-16 17:53:01
3be3967f-2bfb-454c-95d6-d531f9c70394	c2d28373-6c1f-485e-bc49-239874ba0601	efbdfaf5-ee03-4dcf-8283-3eefec54e675	3	Есть существенные недостатки	2020-12-16 19:18:51
32e40d1f-5e88-4be1-84be-410a1ff62da6	c2d28373-6c1f-485e-bc49-239874ba0601	efbdfaf5-ee03-4dcf-8283-3eefec54e675	5	testtesttest	2020-12-03 21:11:55
ba526640-442d-4846-b5bb-0debcdcc4b8a	0aab3e7f-cde2-4b0d-ac93-141c987be013	f691ab28-e35b-4b12-9de2-b2cd2287eb7b	4	testt	2021-06-02 14:13:14
0315b586-4137-43b8-94a4-413400acd02a	0aab3e7f-cde2-4b0d-ac93-141c987be013	4e8abd50-a641-4377-9389-2a5874b081e8	0	\N	2021-06-02 23:45:45
\.


--
-- Data for Name: good; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.good (uuid, name, price, descr, img_path, catalog_uuid) FROM stdin;
efbdfaf5-ee03-4dcf-8283-3eefec54e675	Планшет Acer-r23zl	20000.00	Многофункциональный планшет на платформе Windows	1.jpeg	767a4621-304c-47b8-b9df-8bd3460be3a7
77e17e83-56ac-4d13-a983-786709e68f40	Куртка осенняя	4000.00	Легкая куртка - размер 44		982994c3-c5b1-4564-9416-b526cba23075
8641f4d6-41d1-4905-8005-1afcd3c5a59f	Телефон Samsung S7	25000.00	Мощный смартфон с множеством функций	2.jpeg	767a4621-304c-47b8-b9df-8bd3460be3a7
4e8abd50-a641-4377-9389-2a5874b081e8	Рюкзак спортивный	1999.00	Удобный рюкзак	3.jpeg	982994c3-c5b1-4564-9416-b526cba23075
f691ab28-e35b-4b12-9de2-b2cd2287eb7b	Футболка авторская	1200.00	Распечатан авторский принт доступны размеры 40, 42, 44	4.jpeg	982994c3-c5b1-4564-9416-b526cba23075
d82477f0-60ef-4f95-b365-d6bc0f6612fa	Куртка зимняя	7500.00	Куртка зимняя пуховик - размер 44	5.jpeg	982994c3-c5b1-4564-9416-b526cba23075
40ba12c7-82a4-4481-9cd6-4000eb286815	Шапка зимняя	2000.00	Теплый зимний головной убор	6.jpeg	982994c3-c5b1-4564-9416-b526cba23075
be5a80b9-48a4-4179-b348-7aa4e6c85ce7	Тестовый товар	25000.00	Тестовый товар	555.jpeg	982994c3-c5b1-4564-9416-b526cba23075
\.


--
-- Data for Name: good_request; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.good_request (uuid, request_uuid, good_uuid) FROM stdin;
a5d66291-27c7-4464-98cf-ee035ce36aa0	4db863a4-15c8-4df8-8a24-b30c60d0c3b0	f691ab28-e35b-4b12-9de2-b2cd2287eb7b
692b7f18-d232-48ab-b698-8adfb7cd1b68	38550c19-eda8-423a-949f-84662492138f	f691ab28-e35b-4b12-9de2-b2cd2287eb7b
db64afa7-fddc-45ff-b0b7-877566820f2d	7c2b9171-9ee8-422e-a0a0-2cd3b7d591ea	f691ab28-e35b-4b12-9de2-b2cd2287eb7b
1f5001ee-c499-476b-b5da-814173176532	7c2b9171-9ee8-422e-a0a0-2cd3b7d591ea	efbdfaf5-ee03-4dcf-8283-3eefec54e675
14c159b8-579a-4bff-8e47-cd115f035e92	4db863a4-15c8-4df8-8a24-b30c60d0c3b0	efbdfaf5-ee03-4dcf-8283-3eefec54e675
ca5791c9-f05f-4325-89bd-453d7a26be68	7c2b9171-9ee8-422e-a0a0-2cd3b7d591ea	4e8abd50-a641-4377-9389-2a5874b081e8
e0fbf765-f236-4d35-97bb-569146d34ea2	7c6a19fd-cae0-4064-befa-954b615d7659	efbdfaf5-ee03-4dcf-8283-3eefec54e675
aabc1199-4cab-4300-ba6b-3d9c9077d398	7c6a19fd-cae0-4064-befa-954b615d7659	8641f4d6-41d1-4905-8005-1afcd3c5a59f
90a5ada8-08cc-4b1f-9d5e-e20482ac7c65	344888ca-65a9-416e-8375-93b9afa8fdd2	f691ab28-e35b-4b12-9de2-b2cd2287eb7b
22bc0352-3d8e-488b-8b47-884cbee30a5d	344888ca-65a9-416e-8375-93b9afa8fdd2	d82477f0-60ef-4f95-b365-d6bc0f6612fa
44c4be19-c9ca-4672-9443-76474063590d	04cdf723-e3c7-48c0-b4f8-04c2793e0e98	8641f4d6-41d1-4905-8005-1afcd3c5a59f
23082cdd-4695-45b5-919a-440eb3690ba0	04cdf723-e3c7-48c0-b4f8-04c2793e0e98	4e8abd50-a641-4377-9389-2a5874b081e8
4cdebaf0-944a-4577-91dc-196d3c383973	fe6e8253-dc4c-4d28-9a05-c3387bc21335	8641f4d6-41d1-4905-8005-1afcd3c5a59f
\.


--
-- Data for Name: message; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.message (uuid, chat_uuid, user_uuid, text, "timestamp") FROM stdin;
69cf4714-7551-4a00-bf75-ab55f0326c87	b756705f-89db-4a2b-90e3-75199c4b7965	0aab3e7f-cde2-4b0d-ac93-141c987be013	"Добрый день "	2021-06-02 14:00:48
f0a4c3aa-b938-485c-aea2-8f70b3744469	b756705f-89db-4a2b-90e3-75199c4b7965	0aab3e7f-cde2-4b0d-ac93-141c987be013	"У меня возникли вопросы по заказу"	2021-06-02 20:50:50
f0a4c3aa-b938-485c-aea2-8f70b3744455	b756705f-89db-4a2b-90e3-75199c4b7965	9efdf923-76b5-4604-939c-35ac5cf131d3	"Сейчас разберемся с проблемой"	2021-06-02 20:50:55
\.


--
-- Data for Name: parametr; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parametr (uuid, good_uuid, question, name) FROM stdin;
0b73f097-5974-4afc-800d-347059979b02	f691ab28-e35b-4b12-9de2-b2cd2287eb7b	Доступные цвета: черный, серый, белый	Цвет
1024478a-8a8a-4ade-8965-9c5779caf681	f691ab28-e35b-4b12-9de2-b2cd2287eb7b	Доступные размеры 40,42,44	Размер
cedba592-1648-4e09-8379-93a27b4d48cd	f691ab28-e35b-4b12-9de2-b2cd2287eb7b	Принт сзади или спереди	Расположение принта
\.


--
-- Data for Name: parametr_value; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.parametr_value (uuid, parametr_uuid, good_request_uuid, value) FROM stdin;
1b20df4d-d205-4746-80ee-bbc58691e0f6	0b73f097-5974-4afc-800d-347059979b02	a5d66291-27c7-4464-98cf-ee035ce36aa0	Белый
409cc8c6-c6ab-4436-812b-449f6cfa09c4	1024478a-8a8a-4ade-8965-9c5779caf681	a5d66291-27c7-4464-98cf-ee035ce36aa0	42
d55e9eb6-238f-439d-82a8-ec6d7c3ea1eb	cedba592-1648-4e09-8379-93a27b4d48cd	a5d66291-27c7-4464-98cf-ee035ce36aa0	спереди
\.


--
-- Data for Name: request; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.request (uuid, client_uuid, manager_uuid, payment_data) FROM stdin;
4db863a4-15c8-4df8-8a24-b30c60d0c3b0	012318fb-a204-4729-8a67-898f45f0a125	9efdf923-76b5-4604-939c-35ac5cf131d3	4444555566667777
38550c19-eda8-423a-949f-84662492138f	c2d28373-6c1f-485e-bc49-239874ba0601	9efdf923-76b5-4604-939c-35ac5cf131d3	4444555566667777
7c2b9171-9ee8-422e-a0a0-2cd3b7d591ea	0aab3e7f-cde2-4b0d-ac93-141c987be013	9efdf923-76b5-4604-939c-35ac5cf131d3	4444555566667777
b4526f73-2297-4e3d-8c82-39fd42c5ea8e	0aab3e7f-cde2-4b0d-ac93-141c987be013	012318fb-a204-4729-8a67-898f45f0a125	4444555566667777
7c6a19fd-cae0-4064-befa-954b615d7659	c2d28373-6c1f-485e-bc49-239874ba0601	012318fb-a204-4729-8a67-898f45f0a125	445511223333
344888ca-65a9-416e-8375-93b9afa8fdd2	0aab3e7f-cde2-4b0d-ac93-141c987be013	012318fb-a204-4729-8a67-898f45f0a125	89999
04cdf723-e3c7-48c0-b4f8-04c2793e0e98	b3290c0d-8a76-4619-9401-13d0a2459fd1	9efdf923-76b5-4604-939c-35ac5cf131d3	5885
fe6e8253-dc4c-4d28-9a05-c3387bc21335	0aab3e7f-cde2-4b0d-ac93-141c987be013	012318fb-a204-4729-8a67-898f45f0a125	111122223333444
\.


--
-- Data for Name: status; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.status (uuid, name, prev_status, is_terminal, is_initial) FROM stdin;
461dcf80-3dff-4268-904c-afa19e3b9984	Готов к отправке	1167829b-ecfe-484c-a4fe-3e086d8c4d97	0	0
d579ac13-9e40-40d6-9b25-f36fba781671	Отправлен	461dcf80-3dff-4268-904c-afa19e3b9984	0	0
ad631ed1-a650-4f9c-bfa1-70b84c6f0d10	Закрыт	d579ac13-9e40-40d6-9b25-f36fba781671	1	0
1167829b-ecfe-484c-a4fe-3e086d8c4d97	Ожидание обработки	\N	0	1
\.


--
-- Data for Name: status_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.status_history (uuid, request_uuid, status_uuid, setup_timestamp, comment) FROM stdin;
0f0d4c83-0910-4e5f-9764-4f531e182344	4db863a4-15c8-4df8-8a24-b30c60d0c3b0	461dcf80-3dff-4268-904c-afa19e3b9984	2020-12-03 20:59:29	\N
3e3aeb19-f0b2-48f3-bb77-b064a6125715	4db863a4-15c8-4df8-8a24-b30c60d0c3b0	ad631ed1-a650-4f9c-bfa1-70b84c6f0d10	2020-12-03 20:59:29	Ваш трек номер 88888
1123e69e-5933-43fb-8a33-8f0f00bc6be6	b4526f73-2297-4e3d-8c82-39fd42c5ea8e	1167829b-ecfe-484c-a4fe-3e086d8c4d97	2020-12-17 18:42:40	
460a0e45-3006-410e-8e4a-8e045ee2f1a6	7c6a19fd-cae0-4064-befa-954b615d7659	1167829b-ecfe-484c-a4fe-3e086d8c4d97	2020-12-20 21:29:44	
4f1922a5-214d-49a1-882a-a6b57fdcc638	b4526f73-2297-4e3d-8c82-39fd42c5ea8e	d579ac13-9e40-40d6-9b25-f36fba781671	2020-12-20 23:12:56	ff
35a3c21e-2d04-4254-80fe-e87e50c78d20	b4526f73-2297-4e3d-8c82-39fd42c5ea8e	461dcf80-3dff-4268-904c-afa19e3b9984	2020-12-20 23:12:56	ff
a93d2e6e-f06d-409c-950b-8e45123bc755	b4526f73-2297-4e3d-8c82-39fd42c5ea8e	ad631ed1-a650-4f9c-bfa1-70b84c6f0d10	2021-01-07 21:51:19	\N
7c2b9171-9ee8-422e-a0a0-2cd3b7d591fa	7c2b9171-9ee8-422e-a0a0-2cd3b7d591ea	1167829b-ecfe-484c-a4fe-3e086d8c4d97	2020-12-03 20:59:29	\N
8e442a84-1046-44cf-8695-9eed139e29e0	344888ca-65a9-416e-8375-93b9afa8fdd2	1167829b-ecfe-484c-a4fe-3e086d8c4d97	2021-06-01 14:16:13	\N
6e56ae25-7794-46a2-b42f-1b263de47d72	04cdf723-e3c7-48c0-b4f8-04c2793e0e98	1167829b-ecfe-484c-a4fe-3e086d8c4d97	2021-06-01 15:54:26	\N
8c0b21c2-d423-4360-ad6d-b18aeb1589f5	fe6e8253-dc4c-4d28-9a05-c3387bc21335	1167829b-ecfe-484c-a4fe-3e086d8c4d97	2021-06-18 10:51:04	\N
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."user" (uuid, email, pass, role, name, birth_date, phone) FROM stdin;
c2d28373-6c1f-485e-bc49-239874ba0601	test2@gmail.com	ad0234829205b9033196ba818f7a872b	1	Екатерина	1995-04-12	85554443244
0aab3e7f-cde2-4b0d-ac93-141c987be013	test3@gmail.com	8ad8757baa8564dc136c1e07507f4a98	1	Дмитрий	1998-05-12	85554443277
012318fb-a204-4729-8a67-898f45f0a125	test1@gmail.com	5a105e8b9d40e1329780d62ea2265d8a	2	Александр	1999-02-12	85554443233
6f0c0883-fa8a-4b94-9938-3533f76a835b	test@gmail.com	098f6bcd4621d373cade4e832627b4f6	1	Алексей	1998-05-12	85554444277
251b113e-48a2-4d1b-8831-3b8d47751b44	test9@gmail.com	test9	1	test9	2005-03-15	89048535896
b3afe195-51f9-45e1-bdc2-8fc9364bcbc4	test10@gmail.com	test10	1	test10	2005-07-11	89048535896
b3290c0d-8a76-4619-9401-13d0a2459fd1	test55@gmail.com	test55	1	Владислав	1998-06-01	9996666
45bc9d28-a078-4263-ba49-a8559630406f	admin77@gmail.com	d3e9d6ee443cc1b1aa44ba7d3df1fd50	3	Константин	1995-04-12	85554443232
e4a26676-e61e-49f5-91f2-ec5e3a84383e	adtestest@gmail.com	1844156d4166d94387f1a4ad031ca5fa	1	КонстантинТест	1995-04-12	85554443232
9efdf923-76b5-4604-939c-35ac5cf131d3	manager@gmail.com	1d0258c2440a8d19e716292b231e3190	2	Андрей	1995-04-12	85554443234
\.


--
-- Name: catalog catalog_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.catalog
    ADD CONSTRAINT catalog_pk PRIMARY KEY (uuid);


--
-- Name: chat chat_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT chat_pk PRIMARY KEY (uuid);


--
-- Name: feedback feedback_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_pk PRIMARY KEY (uuid);


--
-- Name: good good_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.good
    ADD CONSTRAINT good_pk PRIMARY KEY (uuid);


--
-- Name: good_request good_request_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.good_request
    ADD CONSTRAINT good_request_pk PRIMARY KEY (uuid);


--
-- Name: message message_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message
    ADD CONSTRAINT message_pk PRIMARY KEY (uuid);


--
-- Name: parametr parametr_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parametr
    ADD CONSTRAINT parametr_pk PRIMARY KEY (uuid);


--
-- Name: parametr_value parametr_value_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parametr_value
    ADD CONSTRAINT parametr_value_pk PRIMARY KEY (uuid);


--
-- Name: request request_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.request
    ADD CONSTRAINT request_pk PRIMARY KEY (uuid);


--
-- Name: status_history status_history_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_history
    ADD CONSTRAINT status_history_pk PRIMARY KEY (uuid);


--
-- Name: status status_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status
    ADD CONSTRAINT status_pk PRIMARY KEY (uuid);


--
-- Name: user user_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pk PRIMARY KEY (uuid);


--
-- Name: all_by_reqeust_count _RETURN; Type: RULE; Schema: public; Owner: postgres
--

CREATE OR REPLACE VIEW public.all_by_reqeust_count AS
 SELECT g.*::public.good AS g,
    ( SELECT ct.name
           FROM public.catalog ct
          WHERE (ct.uuid = g.catalog_uuid)) AS catal,
    count(gr.*) AS request_count
   FROM (public.good g
     LEFT JOIN public.good_request gr ON ((gr.good_uuid = g.uuid)))
  GROUP BY g.uuid
  ORDER BY (count(gr.*)) DESC;


--
-- Name: all_by_grades _RETURN; Type: RULE; Schema: public; Owner: postgres
--

CREATE OR REPLACE VIEW public.all_by_grades AS
 SELECT g.*::public.good AS g,
    ( SELECT ct.name
           FROM public.catalog ct
          WHERE (ct.uuid = g.catalog_uuid)) AS catal,
    avg(f.grade) AS avrg_grade
   FROM (public.good g
     LEFT JOIN public.feedback f ON ((f.good_uuid = g.uuid)))
  GROUP BY g.uuid
  ORDER BY (avg(f.grade)) DESC NULLS LAST;


--
-- Name: user_and_info _RETURN; Type: RULE; Schema: public; Owner: postgres
--

CREATE OR REPLACE VIEW public.user_and_info AS
 SELECT u2.uuid,
    u2.birth_date,
    u2.email,
    u2.name,
    u2.pass,
    u2.phone,
    u2.role,
    count(r.uuid) AS reqests,
    count(m.uuid) AS messeges,
    count(f.uuid) AS feedbacks
   FROM (((public."user" u2
     LEFT JOIN public.request r ON ((r.client_uuid = u2.uuid)))
     LEFT JOIN public.message m ON ((m.user_uuid = u2.uuid)))
     LEFT JOIN public.feedback f ON ((f.user_uuid = u2.uuid)))
  GROUP BY u2.uuid;


--
-- Name: managers_by_requests _RETURN; Type: RULE; Schema: public; Owner: postgres
--

CREATE OR REPLACE VIEW public.managers_by_requests AS
 SELECT m.uuid,
    m.email,
    m.pass,
    m.role,
    m.name,
    m.birth_date,
    m.phone,
    count(rq.*) AS requests
   FROM (public."user" m
     LEFT JOIN public.request rq ON ((rq.manager_uuid = m.uuid)))
  WHERE (m.role = 2)
  GROUP BY m.uuid
  ORDER BY (count(rq.*)) DESC;


--
-- Name: managers_by_worth _RETURN; Type: RULE; Schema: public; Owner: postgres
--

CREATE OR REPLACE VIEW public.managers_by_worth AS
 SELECT m.uuid,
    m.email,
    m.pass,
    m.role,
    m.name,
    m.birth_date,
    m.phone,
    sum(g.price) AS worth
   FROM (public."user" m
     LEFT JOIN public.good g ON ((g.uuid IN ( SELECT gr.good_uuid
           FROM public.good_request gr
          WHERE (gr.request_uuid IN ( SELECT rq.uuid
                   FROM public.request rq
                  WHERE (rq.manager_uuid = m.uuid)))))))
  WHERE (m.role = 2)
  GROUP BY m.uuid
  ORDER BY (sum(g.price)) DESC;


--
-- Name: user_and_info instead_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER instead_trigger INSTEAD OF INSERT OR DELETE OR UPDATE ON public.user_and_info FOR EACH ROW EXECUTE FUNCTION public.instead_of_user_data();


--
-- Name: feedback on_feedback_add; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER on_feedback_add BEFORE INSERT ON public.feedback FOR EACH ROW EXECUTE FUNCTION public.on_feedback_add_func();


--
-- Name: chat chat_fk_client; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT chat_fk_client FOREIGN KEY (client_uuid) REFERENCES public."user"(uuid);


--
-- Name: chat chat_fk_manager; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.chat
    ADD CONSTRAINT chat_fk_manager FOREIGN KEY (manager_uuid) REFERENCES public."user"(uuid);


--
-- Name: feedback feedback_fk_good; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_fk_good FOREIGN KEY (good_uuid) REFERENCES public.good(uuid);


--
-- Name: feedback feedback_fk_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.feedback
    ADD CONSTRAINT feedback_fk_user FOREIGN KEY (user_uuid) REFERENCES public."user"(uuid);


--
-- Name: good good_fk_catalog; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.good
    ADD CONSTRAINT good_fk_catalog FOREIGN KEY (catalog_uuid) REFERENCES public.catalog(uuid);


--
-- Name: good_request good_request_fk_good; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.good_request
    ADD CONSTRAINT good_request_fk_good FOREIGN KEY (good_uuid) REFERENCES public.good(uuid);


--
-- Name: good_request good_request_fk_request; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.good_request
    ADD CONSTRAINT good_request_fk_request FOREIGN KEY (request_uuid) REFERENCES public.request(uuid);


--
-- Name: message message_fk_chat; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message
    ADD CONSTRAINT message_fk_chat FOREIGN KEY (chat_uuid) REFERENCES public.chat(uuid);


--
-- Name: message message_fk_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.message
    ADD CONSTRAINT message_fk_user FOREIGN KEY (user_uuid) REFERENCES public."user"(uuid);


--
-- Name: parametr parametr_fk_good; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parametr
    ADD CONSTRAINT parametr_fk_good FOREIGN KEY (good_uuid) REFERENCES public.good(uuid);


--
-- Name: parametr_value parametr_value_fk_good_req; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parametr_value
    ADD CONSTRAINT parametr_value_fk_good_req FOREIGN KEY (good_request_uuid) REFERENCES public.good_request(uuid);


--
-- Name: parametr_value parametr_value_fk_parametr; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.parametr_value
    ADD CONSTRAINT parametr_value_fk_parametr FOREIGN KEY (parametr_uuid) REFERENCES public.parametr(uuid);


--
-- Name: request request_fk_client; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.request
    ADD CONSTRAINT request_fk_client FOREIGN KEY (client_uuid) REFERENCES public."user"(uuid);


--
-- Name: request request_fk_manager; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.request
    ADD CONSTRAINT request_fk_manager FOREIGN KEY (manager_uuid) REFERENCES public."user"(uuid);


--
-- Name: status_history status_history_fk_request; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_history
    ADD CONSTRAINT status_history_fk_request FOREIGN KEY (request_uuid) REFERENCES public.request(uuid);


--
-- Name: status_history status_history_fk_status; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.status_history
    ADD CONSTRAINT status_history_fk_status FOREIGN KEY (status_uuid) REFERENCES public.status(uuid);


--
-- PostgreSQL database dump complete
--

